import json
import boto3
import os

awsRegion = os.environ['REGION']         # The AWS region where your Kinesis Analytics application is configured.
imageStream= os.environ['KINESIS_STREAM_IMAGE']        # The name of the stream being used as input into the Kinesis Analytics hotspots application
docStream= os.environ['KINESIS_STREAM_DOCS']
feedbackStream = os.environ['KINESIS_STREAM_FEEDBACK']
s3 = boto3.client('s3')
comp_client = boto3.client('comprehend')
kinesis = boto3.client("kinesis",region_name=awsRegion)
lang_codes_snetiments = ['en', 'es', 'fr','de', 'it','pt']
response_list = list()
user_collectionId = os.environ['USER_COLLECTION_ID']
genral_collectionId = os.environ['GENERAL_COLLECTION_ID']


def index_faces(collectionId, bucket, key, imageStream):
    
    client=boto3.client('rekognition')
    out = dict()
    try:
        # create collection if does not exist
        colls = client.list_collections()
        if collectionId not in colls['CollectionIds']: 
            new_coll=client.create_collection(CollectionId=collectionId)
            print('Created Collection ARN: ' + new_coll['CollectionArn'])
            
        response=client.index_faces(CollectionId=collectionId,
                                Image={'S3Object':{'Bucket':bucket,'Name':key}},
                                DetectionAttributes=['ALL'])
        if len(response['FaceRecords']) > 0:
            face = response['FaceRecords'][0]
            out['Face'] = face['Face']
            out['FaceId'] = face['Face']['FaceId']
            out['FaceDetail'] = face['FaceDetail']
            out['collectionId'] = collectionId
            out['bucket'] = bucket
            out['key'] = key
            print(out)
            kinesis_response  = kinesis.put_record(StreamName=imageStream, Data=str(json.dumps(out)), PartitionKey='face')
            print(kinesis_response)
        else:
            return None
    
    except Exception as e:
        print(sys.exc_info()[0])
        return None
    return out
    

# get image data
def get_image_data(bucket, object_key):
    try:
        rekog_client = boto3.client('rekognition')        
        all_labels, all_texts, all_mod, celebrity_info = list(),str(), list(), list()
        face_count = 0
        msg = dict()
        image_params = {'S3Object': {'Bucket': bucket,'Name': object_key}}
        extension = os.path.splitext(object_key)[1][1:]    
        response_labels = rekog_client.detect_labels(Image=image_params)
        response_text = rekog_client.detect_text(Image=image_params)
        response_faces = rekog_client.detect_faces(Image=image_params, Attributes=['ALL'])

        for item in rekog_client.recognize_celebrities(Image=image_params)['CelebrityFaces']:
            celebrity_info.append( {'Urls': item['Urls'], 'Name':item['Name'], 'Id': item['Id'], 'FaceParam':item['Face'] })

        for label in response_labels['Labels']:
            all_labels.append(label['Name'])

        for txt in response_text['TextDetections']:
            # all_texts.append(txt['DetectedText'] + "; Confidence = " + str(label['Confidence'])[:2] )
            if len(txt['DetectedText'])>2:
                all_texts = all_texts + " " + txt['DetectedText']    
        # only JPG ad PNG is supported by Detect Moderation
        if extension.lower() in ['jpg', 'jpeg', 'png']:
            print('Getting Moderation Labels')
            for item in rekog_client.detect_moderation_labels(Image={'S3Object': {'Bucket': bucket,'Name': object_key}}, MinConfidence=50)['ModerationLabels']:
                all_mod.append(item['Name'] + "; Confidence = " + str(item['Confidence'])[:2] + "; ParentName = " + item['ParentName'])
        try:
            face_count = len(response_faces['FaceDetails'])
        except:
            face_count = 0
                
        msg = {'Type': 'image', 'labels':all_labels, 'text': all_texts, 'celebrity' : len(celebrity_info),
                'celebrity_info': celebrity_info, 'face_count': face_count, 'faces': response_faces}         

    except:
        print('Error while processing doc {0}'.format(object_key))
    print(msg)
    return msg
    
# get doc data
def get_text_data(bucket, object_key):
    response = s3.get_object(Bucket=bucket, Key=object_key)
    msg = dict()
    try:
        sentiment, content_text, source_lang = "", "", ""   
        try:
            content_text = response['Body'].read().decode('utf-8')
            if object_key.split('/')[0] == 'Feedback':
                data = json.loads(content_text)
                content_text = data['reviewText'] + 'and  summery is ' + data['summary']
                   
            lang_resp = comp_client.detect_dominant_language(Text=content_text[:1000])
            source_lang = lang_resp['Languages'][0]['LanguageCode'].split('-')[0]            
        except:
            print('error while getting source language')
            source_lang = 'en'
        
        if source_lang in lang_codes_snetiments:            
            sentiment = comp_client.detect_sentiment(Text=content_text[:4999], LanguageCode=source_lang)['Sentiment']           
            entities = comp_client.detect_entities(Text=content_text[:4999], LanguageCode=source_lang)            
            ent_output = dict()
            types = set()
            print(entities)
            for item in entities['Entities']:
                types.add(item['Type'])
            #for k in types:
            #    ent_output[k] = ""
            
            for item in entities['Entities']:
                if item['Type'] in ent_output.keys():
                    ent_output[item['Type']] = ent_output[item['Type']] + "," +  item['Text']
                else:
                    ent_output[item['Type']] = item['Text']

        msg = {'Type': 'doc', 'Sentiment': sentiment, 'Entities': ent_output}
    except:
        print('Error while processing doc {0}'.format(object_key))  
    
    return msg

def lambda_handler(event, context):
    records = event['Records']
    print('******  Event Data **********')
    print(event)
    
    kinesis_response_list = list()
    for record in records:
        response = str()
        kinesis_response = str()
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        response = s3.head_object(Bucket=bucket, Key=key)        
        filename = os.path.basename(key)
        extension = os.path.splitext(key)[1][1:]     
        
        out = {'awsRegion': record['awsRegion']}
        out['@timestamp'] = record['eventTime']
        out['eventName'] = record['eventName']
        out['prncipalId'] = record['userIdentity']
        out['bucket'] = bucket
        out['key'] = key
        out['metadata'] = response['Metadata']
        out['size'] = record['s3']['object']['size']
        out['eTag'] = record['s3']['object']['eTag']
        out['filename'] = filename
        out['extension'] = extension

        if response['ContentType'].split('/')[0] == 'image':
            # get data
            content = get_image_data(bucket, key)
            out['type'] = content['Type'] 
            out['labels'] = content['labels']
            out['text'] = content['text']
            out['celebrity'] = content['celebrity']
            out['celebrity_info'] = content['celebrity_info']
            out['face_count'] = content['face_count']
            out['faces'] = content['faces']
            kinesis_response  = kinesis.put_record(StreamName=imageStream, Data=str(json.dumps(out)), PartitionKey='image')
            index_faces(genral_collectionId, bucket, key, imageStream)
        else:
            content = get_text_data(bucket, key)
            out['type'] = content['Type']               
            out['sentiment'] = content['Sentiment']
            print(content['Entities'])
            for k, v in  content['Entities'].items():
                out[k] = v
                
            if key.split('/')[0] == 'Feedback':
                try:
                    data  = json.loads(s3.get_object(Bucket=bucket, Key=key)['Body'].read().decode('utf-8'))
                    product = key.split('/')[1]
                    out['product']  = product,
                    out['reviewID']  =  data['reviewerID'],
                    out['asin']      =  data['asin'],
                    out['helpful']   =  data['helpful'],
                    out['overall']   =  data['overall'],
                    out['summary']   =  data['summary'],
                    out['reviewTime'] = data['reviewTime'],
                    out['unixReviewTime'] = data['unixReviewTime']
                    kinesis_response  = kinesis.put_record(
                                        StreamName=feedbackStream,
                                        Data=str(json.dumps(out)),
                                        PartitionKey=product)   
                except:
                    print('error while reading json')
            else:
                kinesis_response  = kinesis.put_record(StreamName=docStream, Data=str(json.dumps(out)), PartitionKey='doc')   
            
            
        print(kinesis_response)
        kinesis_response_list.append(kinesis_response)
        
    #print(output_records)
    #response  = kinesis.put_records(StreamName=imageStream, Records=output_records)    
    return {
        "statusCode": 200,
        "body": kinesis_response_list
    }
