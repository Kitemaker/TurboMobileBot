
import json
import os
import logging
import boto3
import requests
import image_analyser
import sys
import botocore
import text_analyser
import re


######## Convert SSML to Card text ############
from html.parser import HTMLParser
from six import PY2
try:
    from HTMLParser import HTMLParser
except ImportError:
    from html.parser import HTMLParser


class SSMLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.full_str_list = []
        if not PY2:
            self.strict = False
            self.convert_charrefs = True

    def handle_data(self, d):
        self.full_str_list.append(d)

    def get_data(self):
        return ''.join(self.full_str_list)


def convert_html_to_text(html_data):
    # convert ssml speech to text, by removing html tags
    s = SSMLStripper()
    s.feed(html_data)
    return s.get_data()


BUCKET = os.environ['BUCKET']
BUCKET_PREFIX = os.environ['BUCKET_PREFIX']
ENDPOINT = os.environ['DOMAIN_ENDPOINT']
USER_COLLECTION_ID = os.environ['USER_COLLECTION_ID']
USER_DATA_STREAM = os.environ['USER_DATA_STREAM']
GENERAL_COLLECTION_ID = os.environ['GENERAL_COLLECTION_ID']

suffix = '/_search'
logger = logging.getLogger()
logger.setLevel(logging.ERROR)
lang_codes_snetiments = ['en', 'es', 'fr','de', 'it','pt']
lang_codes = {'english':'en', 'french':'fr', 'german':'de', 'italian':'it',
              'portugese':'pt', 'russian':'ru', 'spanish':'es', 'turkish':'tr'}
                
polly_lan_codes = {'cy':'cy-GB','da': 'da-DK','de': 'de-DE','en':'en-US', 'es': 'es-ES', 'fr': 'fr-FR', 'is':'is-IS', 'it':'it-IT', 'ja':'ja-JP',
                    'hi':'hi-IN','ko':'ko-KR', 'nb':'nb-NO','nl':'nl-NL', 'pl':'pl-PL', 'pt':'pt-PT', 'ro':'ro-RO','ru':'ru-RU','sv':'sv-SE','tr':'tr-TR'}
     
sorry_lang_not_supported = 'Sorry, language of input text is not supported. Supported languages are:\n' +\
        'english, french, german, italian, portugese, russian, spanish, ' +\
        'and turkish.\nPlease enter the input again..'
                    
s3 = boto3.client('s3')
s3_res = boto3.resource('s3')
comp_client = boto3.client('comprehend')
trans_client = boto3.client('translate')
polly_client = boto3.client('polly')


def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message, response_card):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message,
            'responseCard': response_card
        }
    }



def check_valid_key(bucket, key):
    try:
        print('checking validity of image key')
        response = s3.get_object(Bucket=bucket, Key=key)
        return True
    except botocore.exceptions.ClientError as e:
        error_code = e.response['Error']['Code']
        return False
    return True
        

def confirm_intent(session_attributes, intent_name, slots, message, response_card):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ConfirmIntent',
            'intentName': intent_name,
            'slots': slots,
            'message': message,
            'responseCard': response_card
        }
    }


def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response


def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }


def build_response_card(title, subtitle, options):
    """
    Build a responseCard with a title, subtitle, and an optional set of options which should be displayed as buttons.
    """
    buttons = None
    if options is not None:
        buttons = []
        for i in range(min(5, len(options))):
            buttons.append(options[i])

    return {
        'contentType': 'application/vnd.amazonaws.card.generic',
        'version': 1,
        'genericAttachments': [{
            'title': title,
            'subTitle': subtitle,
            'buttons': buttons
        }]
    }

def parse_int(n):
    try:
        return int(n)
    except ValueError:
        return float('nan')


def build_validation_result(is_valid, violated_slot, message_content):
    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': {'contentType': 'PlainText', 'content': message_content}
    }


def validate_input_language(intent_name, language, input):
    
    if language is None:
        return build_validation_result(False,'Out_Language', "Please specify output language. " +\
        "Supported languages are english, french, german, italian, portugese, russian, spanish and turkish")
        
    if str.lower(language) not in lang_codes.keys():
            return build_validation_result(False,'Out_Language', "Output Language is not supported. Please select any other language." +\
            "Supported languages are english, french, german, italian, portugese, russian, spanish, turkish")
            
    if intent_name == 'TranslateIntent':
        if input == None:
            return build_validation_result(False,'Input_Text', "please enter text")
        if input == "":
            return build_validation_result(False,'Input_Text', "No input provided, please provide text to be trnslated")
            
    if intent_name == 'TranslateFileIntent':
        if input == None:
            return build_validation_result(False,'File_Link', "please enter file key")
        if input == "":
            return build_validation_result(False,'File_Link', "No input provided, please provide key of the file")

    return build_validation_result(True, None, None)
    
def validate_input_create_audio(intent_name, type, input):
    
    if type is None:
        return build_validation_result(False,'Input_Type', "Please specify input type e.g. text of link")
            
    if input is None:
        if type == 'file':
            return build_validation_result(False,'Input_Text', "please enter file link")
        if type == 'text':
            return build_validation_result(False,'Input_Text', "Please provide input text")

    return build_validation_result(True, None, None)
    

def build_options(slot):
    """
    Build a list of potential options for a given slot, to be used in responseCard generation.
    """
        
    if slot == 'Out_Language':
        out_card = list()
        for ln in lang_codes.keys():
            out_card.append({'text':ln,'value':ln})
        return out_card
    options = []       

    return options

""" --- Functions that control the bot's behavior --- """

def translate_input(intent_request):
    slots = intent_request['currentIntent']['slots']
    intent_name = intent_request['currentIntent']['name']
    if 'Out_Language' in slots:
        out_language = slots['Out_Language']
    else:
        out_language = None
        
    if 'Input_Text' in slots:
        input_text = slots['Input_Text']
    else:
        input_text = None
        
    if 'File_Link' in slots:
        file_link = slots['File_Link']
    else:
        file_link = None        
        
    source_lang = 'en'
    resp = ""
        
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        validation_result = validate_input_language(
            intent_name,
            out_language,
            input_text if intent_name == 'TranslateIntent' else file_link
            )
            
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            if validation_result['violatedSlot'] == 'Out_Language':
                cards = build_response_card(
                'Specify output language',
                'Select option',
                build_options(validation_result['violatedSlot']))
            else:
                cards = None
                
            return elicit_slot(
                output_session_attributes,
                intent_request['currentIntent']['name'],
                slots,
                validation_result['violatedSlot'],
                validation_result['message'],
                cards
                )
            
        
        return delegate(output_session_attributes, slots)
    
    if intent_name == 'TranslateIntent':
        resp = comp_client.detect_dominant_language(Text=input_text[0:1000])
    else:             
        response = s3.get_object(Bucket=BUCKET, Key=file_link)
        doc = response['Body'].read()
        logger.debug(doc)
        resp = comp_client.detect_dominant_language(Text=doc[0:1000])
        print("text read is =>" +  doc)

    try:
        source_lang = resp['Languages'][0]['LanguageCode'].split('-')[0]
    except:
        print('error while getting source language')
        source_lang = 'xx'
        
    if source_lang not in lang_codes.values():
        output_content = sorry_lang_not_supported
        slot_to_elicit = 'Input_Text' if intent_name == 'TranslateIntent' else 'File_Link'
        slots[slot_to_elicit] =  None
        return elicit_slot(
                output_session_attributes,
                intent_request['currentIntent']['name'],
                slots,
                slot_to_elicit,
                {'contentType': 'PlainText', 'content': output_content},
                None
                )
    else:
        if intent_name == 'TranslateIntent':
            out_text = trans_client.translate_text(Text=input_text, SourceLanguageCode=source_lang, TargetLanguageCode=lang_codes[out_language])
        else:
            out_text = trans_client.translate_text(Text=doc, SourceLanguageCode=source_lang, TargetLanguageCode=lang_codes[out_language])
            
        print(out_text)
        output_content = out_text['TranslatedText']
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': output_content
        }
    )


def create_audio(intent_request):
    
    if 'Input_Type' in intent_request['currentIntent']['slots']:
        input_type = intent_request['currentIntent']['slots']['Input_Type']
    else:
        input_type = None
        
    if 'Input_Text' in intent_request['currentIntent']['slots']:
        input_text = intent_request['currentIntent']['slots']['Input_Text']
    else:
        input_text = None
        
    source_lang = 'en'
    resp = ""
        
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    intent_name = intent_request['currentIntent']['name']

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        slots = intent_request['currentIntent']['slots']
        validation_result = validate_input_create_audio(intent_name, input_type, input_text)
            
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            if validation_result['violatedSlot'] == 'Input_Type':
                cards = build_response_card(
                'Specify input type',
                'Select option',
                [{'text':'text','value':'text'},{'text':'file','value':'file'}])
            else:
                cards = None
                
            return elicit_slot(
                output_session_attributes,
                intent_request['currentIntent']['name'],
                slots,
                validation_result['violatedSlot'],
                validation_result['message'],
                cards
                )
            
        
        return delegate(output_session_attributes, slots)
    
    if str.lower(input_type) == 'text':
        resp = comp_client.detect_dominant_language(Text=input_text[0:1000])
    else:             
        doc = convert_html_to_text(requests.get(input_text).text.decode('utf-8'))
        resp = comp_client.detect_dominant_language(Text=doc[0:1000])
        print("text read is =>" +  doc)

    try:
        source_lang = resp['Languages'][0]['LanguageCode'].split('-')[0]
        print(source_lang)
    except:
        print('error while getting source language')
        source_lang = 'en'
        
    if source_lang not in polly_lan_codes.keys():
        output_content = "Sorry input language is not supported. Please check the input"
    else:
        voice = polly_client.describe_voices(LanguageCode=polly_lan_codes[source_lang])['Voices'][0]
        
        task_response = polly_client.start_speech_synthesis_task(
                OutputFormat='mp3', OutputS3BucketName = BUCKET,
                OutputS3KeyPrefix = BUCKET_PREFIX, Text=input_text,
                TextType='text', VoiceId=voice['Id'])
        
        print(task_response)
        output_content = 'Audio file creation has started. Audio file shall be available at location : Bucket = \'{0}\' , URI = {1}'.format(
                            BUCKET, task_response['SynthesisTask']['OutputUri']
                            )
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': output_content
        }
    )


def validate_input_analyse_image(intent_request, key):
    if key is None:
        return build_validation_result(False,'Key', "Please enter image key")
    else:
        if check_valid_key(BUCKET, key) == False:
            return build_validation_result(False,'Key', "Image key  {0} is not valid. Please check the input".format(key))
    return build_validation_result(True, None, None)
    
    
def recognise_image(intent_request):
    
    if 'Key' in intent_request['currentIntent']['slots']:
        image_key = intent_request['currentIntent']['slots']['Key']
    else:
        image_key = None
    
    resp = ""
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    intent_name = intent_request['currentIntent']['name']

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        slots = intent_request['currentIntent']['slots']
        validation_result = validate_input_analyse_image(intent_request, image_key)
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            return elicit_slot(
                output_session_attributes,
                intent_request['currentIntent']['name'],
                slots,
                validation_result['violatedSlot'],
                validation_result['message'],
                None    
                )
        
        return delegate(output_session_attributes, slots)
        
    # TO DO     file_info = get_bucket_and_key_from_uri(file_link)
    
    output_content = image_analyser.get_image_analysis(BUCKET, image_key)
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': output_content
        })


def validate_input_text_analyser(intent_name, link):
    
    if link is None:
        return build_validation_result(False,'File', "Please provide S3 file key or link")
    else:
        if (file_link[0:8] == 'https://'  or file_link[0:7] == 'http://') == False :
            if check_valid_key(BUCKET, link) == False:
                return build_validation_result(False,'File', "File key is not valid. Please provide S3 file key or link")
    return build_validation_result(True, None, None)  

def analyse_text_file(intent_request):
    slots = intent_request['currentIntent']['slots']
    if 'File' in slots:
        file_link = slots['File']
    else:
        file_link = None
        
    output_content = str()
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    intent_name = intent_request['currentIntent']['name']

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        validation_result = validate_input_text_analyser(intent_name, file_link)
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            return elicit_slot(
                output_session_attributes,
                intent_request['currentIntent']['name'],
                slots,
                validation_result['violatedSlot'],
                validation_result['message'],
                None    
                )
                
        return delegate(output_session_attributes, slots)
        

    output_content = text_analyser.analyse_text_conent(BUCKET, file_link)
    if output_content is None:
        output_content = sorry_lang_not_supported
        slot_to_elicit = 'File'
        slots[slot_to_elicit] =  None
        return elicit_slot(
                output_session_attributes,
                intent_request['currentIntent']['name'],
                slots,
                slot_to_elicit,
                {'contentType': 'PlainText', 'content': output_content},
                None
                )
        
    
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': json.dumps(output_content)
        }
    )
    
    
    
def find_images(intent_request):
    slots = intent_request['currentIntent']['slots']
    if 'Label' in slots:
        label = slots['Label']
    else:
        label = None
        
    output_content = str()
    query_result = list()
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    intent_name = intent_request['currentIntent']['name']

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        validation_result = validate_input_text_analyser(intent_name, label)
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            return elicit_slot(
                output_session_attributes,
                intent_request['currentIntent']['name'],
                slots,
                validation_result['violatedSlot'],
                validation_result['message'],
                None    
                )
                
        return delegate(output_session_attributes, slots)
    
    query = {'q': label} 
    
    response = requests.get(ENDPOINT + suffix, params=query)
    
    if response.status_code == 200:
        response = response.json()['hits']['hits']
        for item in response:
            if 'key' in item['_source']:
                query_result.append(item['_source'])
        
        print(query_result)
        count = 0
        if len(query_result) > 0:
            key_list = list()
            for item in query_result:
                if 'key' in item and count <5:
                    key_list.append('https://s3.amazonaws.com/' + item['bucket'] + '/' + item['key'])
                    count = count + 1 
            
            if len(query_result) > 5:
                output_content = str(len(query_result)) + ' item found 5 results are:\n ' +  '  , \n'.join(key_list)
            else:
                output_content = str(len(query_result)) + ' item found:\n ' +  '  , \n'.join(key_list)
                
            
        else:
            output_content = 'Sorry! no match found'
        
    elif response.status_code == 400:
        output_content = "Invalid request. Please try again"
    else:
        output_content = "Sorry no match found. Please try again"
        
    print(response)
    
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': output_content
        }
    )
    

def validate_input_index_image(intent_name, name, id, key):
    
    if name is None:
        return build_validation_result(False,'Name', "Please enter user Name")
    else:        
        p = re.compile('[^0-9a-zA-Z_ ]')
        if p.search(name) is not None:
            return build_validation_result(False,'Name', "Only \"0-9a-zA-Z _\" are allowed. Please enter valid user Name")

    if id is None:
        return build_validation_result(False,'UserId', "Please enter user ID")        
    else:        
        p = re.compile('[^0-9]')
        if p.search(id) is not None:
            return build_validation_result(False,'UserId', "Only numbers \"0-9\" are allowed. Please enter valid user ID")
        if len(id) > 4:
            return build_validation_result(False,'UserId', "Invalid user Id. Please enter 4 digit user ID")
        
    if key is None:
        return build_validation_result(False,'Key', "Please enter image Key")        
    else:   
        if check_valid_key(BUCKET, key) == False:
            return build_validation_result(False,'Key', "Image Key is not valid, Please enter valid key")
            
    return build_validation_result(True, None, None) 

def index_image(intent_request):
    slots = intent_request['currentIntent']['slots']
    if 'Name' in slots:
        name = slots['Name']
    else:
        name = None

    if 'UserId' in slots:
        userid = slots['UserId']
    else:
        userid = None

    if 'Key' in slots:
        key = slots['Key']
    else:
        key = None
        
    print([name,userid,key])
        
    output_content = str()    
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    intent_name = intent_request['currentIntent']['name']

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        validation_result = validate_input_index_image(intent_name, name, userid, key)
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            return elicit_slot(
                output_session_attributes,
                intent_request['currentIntent']['name'],
                slots,
                validation_result['violatedSlot'],
                validation_result['message'],
                None  
                )
                
        return delegate(output_session_attributes, slots)
    
    print('calling function')
    response = image_analyser.index_faces(USER_COLLECTION_ID, BUCKET, key, userid, name, USER_DATA_STREAM)
    if response is not None and 'UserName' in response and 'FaceId' in response:
        output_content = "Image of user \'{0}\' is listed successfully with FaceId \'{1}\'".format(response['UserName'], response['FaceId'])
    else:
        output_content = "Due to some error , operation is not successful. Please try again"
        
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': json.dumps(output_content)
        }
    )
    

def validate_input_search_face(intent_name, key):    
           
    if key is None:
        return build_validation_result(False,'Key', "Please enter image Key")        
    else:   
        if check_valid_key(BUCKET, key) == False:
            return build_validation_result(False,'Key', "Image Key is not valid, Please enter valid key")
            
    return build_validation_result(True, None, None) 

def search_face(intent_request):
    
    if 'Key' in intent_request['currentIntent']['slots']:
        key = intent_request['currentIntent']['slots']['Key']
    else:
        key = None
        
    output_content = str()
    query_result = list()
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    intent_name = intent_request['currentIntent']['name']

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        slots = intent_request['currentIntent']['slots']
        validation_result = validate_input_search_face(intent_name, key)
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            return elicit_slot(
                output_session_attributes,
                intent_request['currentIntent']['name'],
                slots,
                validation_result['violatedSlot'],
                validation_result['message'],
                None    
                )
                
        return delegate(output_session_attributes, slots)
    
    try:
        if intent_name == 'SearchUserIntent':
            face_list = image_analyser.search_faces_in_image(ENDPOINT + '/users*' + suffix, USER_COLLECTION_ID, BUCKET, key)
        else:
            face_list = image_analyser.search_faces_in_image(ENDPOINT + suffix, GENERAL_COLLECTION_ID, BUCKET, key)
            
        if len(face_list) > 0:
            output_content = 'found {0} match. \n'.format(len(face_list)) + " \n".join(face_list)
        else:
            output_content= 'could not found any match'
    except:
        print(sys.exc_info())
        output_content = 'Error while getting results.'
        raise Exception('Error while getting results.')
    
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': output_content
        }
    )
    
def hello_response(intent_request):
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    output_content =  'Hi! I am Turbo Bot, to start a task please enter one of the following options:\n' +\
    'translate,\nfind image,\n list face,\n search face,\nsearch user,\ncreate audio file'
                
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': output_content
        }
    )   
    
    

def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """
    intent_name = intent_request['currentIntent']['name']
    try:
    
        if intent_name in ['TranslateIntent', 'TranslateFileIntent']:
            return translate_input(intent_request)
            
        if intent_name == 'CreateAudioIntent':
            return create_audio(intent_request)
            
        if intent_name == 'TextAnalysisIntent':
            return analyse_text_file(intent_request)
        
        if intent_name == 'RecogniseImageIntent':
            return recognise_image(intent_request)
        
        if intent_name == 'FindImageIntent':
            return find_images(intent_request)
            
        if intent_name == 'IndexFaceIntent':
            return index_image(intent_request)
            
        if intent_name in ['SearchFaceIntent', 'SearchUserIntent'] :
            return search_face(intent_request)
            
        if intent_name == 'HelloIntent':
            return hello_response(intent_request)
            
    except:
        print(sys.exc_info())
        raise Exception('Error while getting results.')
        
    raise Exception('Intent with name ' + intent_name + ' not supported')


""" --- Main handler --- """

def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    """
    return dispatch(event)






