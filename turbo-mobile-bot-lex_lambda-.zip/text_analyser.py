
import json
import os
import logging
import boto3
import requests
import echo_translator_lex_backend as home

######## Convert SSML to Card text ############
comp_client = boto3.client('comprehend')
s3 = boto3.client('s3')
lang_codes_snetiments = ['en', 'es', 'fr','de', 'it','pt']
response_list = list()

def analyse_text_conent(bucket, file_link):
    try:
        sentiment= ""
        end_output = ""
        content_text = ""
        source_lang = ""
        try:
            if (file_link[0:8] == 'https://'  or file_link[0:7] == 'http://') :
                content_text = convert_html_to_text(requests.get(file_link).text)
            else:
                response = s3.get_object(Bucket=bucket, Key=file_link)
                content_text = response['Body'].read().decode('utf-8')
            
            lang_resp = comp_client.detect_dominant_language(Text=content_text[:2000])
            source_lang = lang_resp['Languages'][0]['LanguageCode'].split('-')[0]
            
        except:
            print('error while getting source language')
            source_lang = 'en'
        
        if source_lang in lang_codes_snetiments:
            sentiment = comp_client.detect_sentiment(Text=content_text[:4999], LanguageCode=source_lang)['Sentiment']
            entities = comp_client.detect_entities(Text=content_text[:4999], LanguageCode=source_lang)
            ent_output = dict()
            types = set()
            print(entities)
            for item in entities['Entities']:
                types.add(item['Type'])
            for k in types:
                ent_output[k] = ""
                
            for item in entities['Entities']:
                types.add(item['Type'])
                ent_output[item['Type']] = ent_output[item['Type']] + "," + ( item['Text'])
        else:
            return None
            
                
        return {
                'Sentiment': sentiment,
                'Entities': ent_output
            
        }
    except:
        return 'Error while processing doc {0}. Please check if the input.'.format(file_link)
        
        

    
    
