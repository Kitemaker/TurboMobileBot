import json
import os
import logging
import boto3
import requests
import sys
import botocore



def get_bucket_and_key_from_uri(file_uri):
    bucket = ''
    key = ''
    extension = ''
    temp = file_uri.replace('https://s3.amazonaws.com/', '')
    bucket = temp.split('/')[0]
    key = temp.replace(bucket + "/", '')
    extension = file_uri.split('.')[-1]
    return {'bucket':bucket, 'key': key , 'extension': extension}
    
    
def get_image_analysis(bucket, object_key):
    try:
        s3 = boto3.client('s3')
        rekog_client = boto3.client('rekognition')
        try:
            response = s3.get_object(Bucket=bucket, Key=object_key)
        except botocore.exceptions.ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == '404':
                return "File key {0} does not exist. Please check input".format(object_key)
        all_labels, all_texts, all_mod, celebrity_info = list(),str(), list(), list()
        face_count = 0
        msg = dict()
        image_params = {'S3Object': {'Bucket': bucket,'Name': object_key}}
        extension = os.path.splitext(object_key)[1][1:]
        if response['ContentType'].split('/')[0] == 'image':
            response_labels = rekog_client.detect_labels(Image=image_params)
            response_text = rekog_client.detect_text(Image=image_params)
            face_count = len(rekog_client.detect_faces(Image=image_params)['FaceDetails'])
            
            for item in rekog_client.recognize_celebrities(Image=image_params)['CelebrityFaces']:
                celebrity_info.append('Name: {0}, Url: {1}'.format(item['Name'], item['Urls']))
            if len(celebrity_info) == 0:
                celebrity_info = 'None'
    
            for label in response_labels['Labels']:
                all_labels.append(label['Name'])
            all_labels = ", ".join(all_labels)
    
            for txt in response_text['TextDetections']:
                if len(txt['DetectedText'])>2:
                    all_texts = all_texts + " " + txt['DetectedText']
                if all_texts == '':
                    all_texts = 'None'
            
            # only JPG ad PNG is supported by Detect Moderation
            if extension.lower() in ['jpg', 'jpeg', 'png']:
                print('Getting Moderation Labels')
                for item in rekog_client.detect_moderation_labels(Image={'S3Object': {'Bucket': bucket,'Name': object_key}}, MinConfidence=30)['ModerationLabels']:
                    all_mod.append(item['Name'] + "; Confidence = " + str(item['Confidence'])[:2] + "; ParentName = " + item['ParentName'])
                
                all_mod = ', '.join(all_mod)
                    
            msg = 'Faces detected: {0},\n Image Labels: {1},\n text detected: {2},\n Celebrity Info: {3},\n Moderation: {4}'.format(
                   face_count, all_labels, all_texts,celebrity_info, all_mod)
            
        return msg
    except:
        return 'Error while processing image {0}. Please check the input.'.format(object_key)
    
def get_images_info_from_bucket(bucket):
    return "got bucket method for {0}".format(bucket)
    
    
def index_faces(collectionId, bucket, key, externalId, username, imageStream):
    kinesis = boto3.client("kinesis" ,region_name='us-east-1')
    client=boto3.client('rekognition')
    out = dict()
    try:
        print('calling index_faces {0} ,  {1} , {2} , {3} {4}  {5}'.format(collectionId, bucket, key, externalId, username, imageStream))
        response = client.index_faces(
            CollectionId=collectionId,
            Image={'S3Object':{'Bucket':bucket,'Name':key}},
            ExternalImageId=str(externalId),
            DetectionAttributes=['ALL']
            )
    
        print(response)						
        if len(response['FaceRecords']) > 0:
            face = response['FaceRecords'][0]
            out['UserName'] = username
            out['ExternalImageId '] = face['Face']['ExternalImageId']
            out['Face'] = face['Face']
            out['FaceId'] = face['Face']['FaceId']
            out['FaceDetail'] = face['FaceDetail']
            out['collectionId'] = collectionId
            out['bucket'] = bucket
            out['key'] = key
            print(out)
            kinesis_response  = kinesis.put_record(StreamName=imageStream, Data=str(json.dumps(out)), PartitionKey='face')
            print(kinesis_response)
        else:
            return None
    
    except Exception as e:
        print(sys.exc_info()[0])
        return None
    return out
    
    
def search_faces_in_image(endpoint , collectionId, bucket, key):
        
    client=boto3.client('rekognition')
    USER_COLLECTION_ID = os.environ['USER_COLLECTION_ID']
    USER_DATA_STREAM = os.environ['USER_DATA_STREAM']
    threshold = 70
    maxFaces=5
    output = list()
    response=client.search_faces_by_image(CollectionId=collectionId,
                                Image={'S3Object':{'Bucket':bucket,'Name':key}},
                                FaceMatchThreshold=threshold,
                                MaxFaces=maxFaces)                                
    faceMatches=response['FaceMatches']
    count_match = len(faceMatches)
    print('Matching faces = '+ str(count_match))
    for match in faceMatches:
        query = {'q': 'FaceId:' + match['Face']['FaceId']}
        response = requests.get(endpoint, params=query).json()['hits']['hits']
        
        if len(response) > 0:
            link = 'https://s3.amazonaws.com/' + response[0]['_source']['bucket'] + '/' + response[0]['_source']['key']
            if collectionId == USER_COLLECTION_ID:
                
                output.append(' User ID : {0}\n FaceId : {1}\n User Name : {2}\n Image Url : {3}'.format(
                                  match['Face']['ExternalImageId'],
                                  match['Face']['FaceId'],
                                  response[0]['_source']['UserName'],
                                  link))
            else:
                output.append(link)
        
    print(output)
    return(output)
    
    

